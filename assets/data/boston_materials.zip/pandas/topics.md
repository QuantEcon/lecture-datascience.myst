* ~~Intro~~
  -  What is a Series/DataFrame?
  - head/tail
  - dtypes
  - Creating new columns
  - Adding columns
* ~~Intro 2: subsetting and basic functionality (reduction/rename)~~
  - identify index/col
  - Indexing -> `loc`
    + .isin
  - Reductions -> sum/min/max/`mean`/var/std/describe
  - Other methods? rename, unique
* ~~Importance of an index~~
  - Make sure to emphasize adding two DataFrames together is done on index/column
  - Missing data
  - Multi-index
  - reset_index, set_index
* ~~Data storage formats~~
  - excel
  - csv
  - feather
  - sql
* Read in data
  - from and to methods
  - Common options: subset of data (rows or columns)
  - encoding... crap...
  - Online files
  - pandas_datareader
  - Optional/advanced (maybe separate module): Rest APIs
* ~~Cleaning data~~
  - string methods
  - dropna/fillna/isnull
* ~~Concat/Join/Merge~~
* Reshaping
  - stack, unstack, melt, pivot
  - level swap
* ~~Time-series~~
  - pct_change/diff
  - rolling window computations
  - year by year comparisons
  - Resampling
  - `to_datetime`... Custom format strings
  - the .month/.year etc... (`df["Date"].dt.year` or if in index `df.index.year`)
  - frequency short-hand
  - String indexing
* ~~Groupby~~
  - apply (using own functions... what do these look like?)
  - `pd.grouper` with one column and another with a datetime column
  - time series columns `pd.Grouper(key=..., freq=...)`
  - Group by columns and an index (I think it is `groupby(["colname", pd.Grouper(level=...)])`)
* ~~Basic Plots~~
  - DataFrame plot methods
  - `kind=scatter/line/bar...`
* Advanced export to excel notebook
  - Freeze rows/columns
  - Multiple sheets
  - Background color, ..., styling, font...
* Parallel?
  - Can we give a baby version that helps them be productive
  - Dask?

## Misc notes
