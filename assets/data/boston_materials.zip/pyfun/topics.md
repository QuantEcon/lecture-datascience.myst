* Intro
  - What is a programming language
  - Why Python?
* Step 1:
  - Variable assignment
  - print
  - help?!?
* ~Numbers~
* ~Booleans~
* ~Strings~
* ~List/Tuple~
  - What is an iterable?
  - zip/enumerate
* ~Dict~
* Base Functions
  - type/len/print/...
* Loops
* ~Conditionals~
* ~User defined functions~
  - Scope
* Classes (not part of normal curriculum)
* datetime (TBD)
* math (numpy works on list whereas math doesn't)
* time
* sys/os
* re

